def connect_to_mongodb():
    global records
    if records is None:
        client = MongoClient("localhost", 27017)
        db = client.get_database('tasks')  # Replace 'your_database_name' with your actual database name
        records = db.tasks  # Assuming 'tasks' is the name of your collection
    return records  #