from flask import Flask, render_template, request, url_for, redirect, session, jsonify
from pymongo import MongoClient
import bcrypt
from flask.json import JSONEncoder
from bson import ObjectId

app = Flask(__name__)
app.secret_key = "testing"

client = MongoClient("localhost", 27017)
db = client.get_database('total_records')
users_collection = db.users
tasks_collection = db.tasks

class CustomJSONEncoder(JSONEncoder):
    def default(self, obj):
        if isinstance(obj, ObjectId):
            return str(obj)
        return JSONEncoder.default(self, obj)

app.json_encoder = CustomJSONEncoder




@app.route("/", methods=['POST', 'GET'])
def index():
    message = ''
    if "email" in session:
        return redirect(url_for("logged_in"))
    
    if request.method == "POST":
        user = request.form.get("fullname")
        email = request.form.get("email")
        password1 = request.form.get("password1")
        password2 = request.form.get("password2")
        role = "user"  # You can add a field to select role in the form

        user_found = users_collection.find_one({"name": user})
        email_found = users_collection.find_one({"email": email})

        if user_found:
            message = 'There already is a user by that name'
            return render_template('index.html', message=message)
        if email_found:
            message = 'This email already exists in the database'
            return render_template('index.html', message=message)
        if password1 != password2:
            message = 'Passwords should match!'
            return render_template('index.html', message=message)
        
        hashed = bcrypt.hashpw(password2.encode('utf-8'), bcrypt.gensalt())
        
        user_input = {'name': user, 'email': email, 'password': hashed, 'role': role}
        users_collection.insert_one(user_input)
        user_data = users_collection.find_one({"email": email})
        new_email = user_data['email']
        return render_template('logged_in.html', email=new_email)
    
    return render_template('index.html')


@app.route("/login", methods=["POST", "GET"])
def login():
    message = 'Please login to your account'
    if "email" in session:
        return redirect(url_for("logged_in"))

    if request.method == "POST":
        email = request.form.get("email")
        password = request.form.get("password")

        user = users_collection.find_one({"email": email})
        if user:
            email_val = user['email']
            passwordcheck = user['password']
            if bcrypt.checkpw(password.encode('utf-8'), passwordcheck):
                session["email"] = email_val
                session["role"] = user.get("role")  # Set the user's role in the session
                if session["role"] == "admin":
                    return redirect(url_for('admin'))  # Redirect to admin route
                else:
                    return redirect(url_for('logged_in'))
            else:
                if "email" in session:
                    return redirect(url_for("logged_in"))
                message = 'Wrong password'
                return render_template('login.html', message=message)
        else:
            message = 'Email not found'
            return render_template('login.html', message=message)
    return render_template('login.html', message=message)


@app.route("/admin")
def admin():
    role = session.get("role") 

    if role == "admin":  
        return render_template('admin.html', role=role) 
    else:
      
        return render_template('login.html')


@app.route('/logged_in')
def logged_in():
    if "email" in session:
        email = session["email"]
        return render_template('logged_in.html', email=email)
    else:
        return redirect(url_for("login"))
    
    
    
@app.route('/get_users', methods=['GET'])
def get_users():
    user = []
    if "email" in session:
        email = session["email"]
        user = users_collection.find_one({"email": email})

    if user:
        user_data = {
            "_id": str(user['_id']),
            "name": user.get("name"),
            "email": user.get("email"),
            "role": user.get("role","user")  # Replace with the correct field name for role
            # Add other fields as needed
        }

        return jsonify({"user": user_data})
    else:
        return jsonify({"message": "User not found"})
    
    
    
@app.route('/get_all_users', methods=['GET'])
def get_all_users():
    all_users = list(users_collection.find({}, {'_id': 1,'name':1,'email':1}))  # Fetch only the _id field

    if all_users:
        for user in all_users:
            # Check if the '_id' field exists in the user data
            if '_id' in user:
                user['_id'] = str(user['_id'])  # Convert _id to string if present

        return jsonify({'users': all_users})
    else:
        return jsonify({'message': 'No users found'})



@app.route("/logout", methods=["POST", "GET"])
def logout():
    if "email" in session:
        session.pop("email", None)
        return render_template("signout.html")
    else:
        return render_template('index.html')    

@app.route("/add_task", methods=['POST'])
def add_task():
    if "email" in session:
        email = session["email"]

        task_name = request.form.get("task_name")
        description = request.form.get("description")
        due_date = request.form.get("due_date")
        status = request.form.get("status")

        task_data = {
            "task_name": task_name,
            "email": email,
            "description": description,
            "due_date": due_date,
            "status": status
        }

        tasks_collection.insert_one(task_data)

    return redirect(url_for('login'))


# third
@app.route('/get_tasks', methods=['GET'])
def get_tasks():
    if "email" in session:
        user_email = session["email"]
        user_role = session.get("role")  # Retrieve user's role from the session

        # If the user is an admin, fetch tasks for the specific user's email provided in the URL parameter
        if user_role == "admin":
            if request.args.get('user_email'):
                user_email = request.args.get('user_email')

            tasks = list(tasks_collection.find({"email": user_email}))
            return jsonify({'tasks': tasks})
        else:  # For non-admin users, fetch only their tasks
            tasks = list(tasks_collection.find({"email": user_email}))
            return jsonify({'tasks': tasks})
    else:
        return redirect(url_for("login"))  # Redirect to login if not logged in

@app.route("/view_task/<task_id>", methods=["GET"])
def view_task(task_id):
    
    task = tasks_collection.find_one({"_id": ObjectId(task_id)})
    if task:
        # Render a template or return JSON response with task details
        return jsonify({'task': task})
    else:
        return jsonify({'message': 'Task not found'}), 404

@app.route("/update_task/<task_id>", methods=["PUT"])
def update_task(task_id):
    task = tasks_collection.find_one({"_id": ObjectId(task_id)})
    if task:
        # Retrieve updated task data from the request
        updated_data = {
            "task_name": request.json.get("task_name"),
            "description": request.json.get("description"),
            "due_date": request.json.get("due_date"),
            "status": request.json.get("status")
        }

        # Update the task in the database
        tasks_collection.update_one({"_id": ObjectId(task_id)}, {"$set": updated_data})

        return jsonify({'message': 'Task updated successfully'})
    else:
        return jsonify({'message': 'Task not found'}), 404

    
@app.route("/delete_task/<task_id>", methods=["DELETE"])
def delete_task(task_id):
    task = tasks_collection.find_one({"_id": ObjectId(task_id)})
    if task:
        # Delete the task from the database
        tasks_collection.delete_one({"_id": ObjectId(task_id)})

        return jsonify({'message': 'Task deleted successfully'})
    else:
        return jsonify({'message': 'Task not found'}), 404
    
    

if __name__ == "__main__":
    app.run(debug=True, host='0.0.0.0', port=5000)

